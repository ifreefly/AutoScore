/**@author:idevcod
 */
package idevcod;

public class App
{
    public boolean init() {
        return true;
    }
    
    public void exception() {
        throw new UnsupportedOperationException();
    }
}
